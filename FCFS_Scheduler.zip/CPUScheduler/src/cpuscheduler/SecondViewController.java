/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpuscheduler;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author PCnet Computers
 */
public class SecondViewController implements Initializable {
    
    @FXML
    private TableView<Data> WTtable;
    @FXML
    private TableColumn<Data,String> pName,colourColumn;
    @FXML
    private TableColumn<Data,Integer> AT;
    @FXML
    private TableColumn<Data,Integer> BT;
    @FXML
    private TableColumn<Data,Integer> WT;
    @FXML
    private TableColumn<Data,Integer> TAT;
    @FXML
    private Label AWT,ATAT,AWTval,ATATval;
    @FXML
    private Button computeButton,backButton,ganttButton;
    private ObservableList<Process> dList;
    protected static ObservableList<Data> wtData =
        FXCollections.observableArrayList(
        );

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pName.setCellValueFactory(new PropertyValueFactory<Data, String>("processName"));
        AT.setCellValueFactory(new PropertyValueFactory<Data, Integer>("arrivalTime"));
        BT.setCellValueFactory(new PropertyValueFactory<Data,Integer>("burstTime"));
        WT.setCellValueFactory(new PropertyValueFactory<Data, Integer>("waitingTime"));
        TAT.setCellValueFactory(new PropertyValueFactory<Data, Integer>("turnaroundTime"));
        colourColumn.setCellValueFactory(new PropertyValueFactory<Data, String>("colour"));
        // TODO
        WTtable.setItems(wtData);
        WTtable.setEditable(true);
        setColorColumn();
    } 
    
    public void setList(ObservableList<Process> dList) throws Exception{
        this.dList = dList;
        
    }
    public ObservableList<Process> getList(){
        return this.dList;
    }
    
    /**
     *
     * @return
     */
    public ObservableList<Data> getDataList(){
        return this.wtData;
    }
    
    
    @FXML
    public void onComputeAction(ActionEvent event){
        FCFS fcfs = new FCFS();
        
        
             
        for (int i = 0; i < getList().size(); i++)
        {
            String process = (String) getList().get(i).getProcessName();
            int at =  getList().get(i).getArrivalTime();
            int bt = getList().get(i).getBurstTime();
            fcfs.add(new Row(process, at, bt));
            
        }
        
        fcfs.process();
        for (int i = 0; i < getList().size(); i++)
        {
            String process = (String) getList().get(i).getProcessName();
            Row row = fcfs.getRow(process);
            Event e = fcfs.getEvent(row);
            Data d = new Data();
            d.setProcessName(process);
            d.setArrivalTime(row.getArrivalTime());
            d.setBurstTime(row.getBurstTime());
            d.setWaitingTime(row.getWaitingTime());
            d.setTurnaroundTime(row.getTurnaroundTime());
            d.setxValue(e.getStartTime());
            WTtable.getItems().add(d);
               
        }


        AWTval.setText(Double.toString(fcfs.getAverageWaitingTime()));
        ATATval.setText(Double.toString(fcfs.getAverageTurnAroundTime()));


    }
    
    @FXML public void setColorColumn(){
        colourColumn.setCellFactory(column -> {
            return new TableCell<Data, String>() {
                int color = 0;
                String colors[] = new String[]{"darkblue","darkcyan","darkred","darkgreen","darkmagenta","darkgoldenrod","darksalmon","darkkhaki","mediumspringgreen","magenta","hotpink","deepskyblue","khaki","fuchsia","black","orange","forestgreen","cornflowerblue","crimson","midnightblue","mediumvioletred"};
                @Override
                protected void updateItem(String item, boolean empty) {

                    super.updateItem(item, empty);
                    if (item == null || empty) {
                        setText(null);
                        setStyle("");
                    } else {
                        if(getIndex() > -1){
                            String color = colors[getIndex() % 20];
                            setStyle("-fx-background-color: "+ color + ";");
                        }
                    }
                }
            };
        });
    }
    
    @FXML
    public void onBackAction(ActionEvent event) throws IOException{
        Parent wtRoot = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene wtScene = new Scene(wtRoot);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(wtScene);
        window.show();
    }
    
    @FXML
    public void displayGanttChart(ActionEvent event){
        GanttChartDisplay gcd= new GanttChartDisplay();
        gcd.init();
    }

    
}
