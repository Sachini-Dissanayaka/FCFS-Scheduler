/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpuscheduler;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

/**
 *
 * @author PCnet Computers
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TableView<Process> table;
    @FXML
    private TextField nameInput , arrivalInput, burstInput;
    @FXML
    private TableColumn<Process,String> pName;
    @FXML
    private TableColumn<Process,Integer> AT;
    @FXML
    private TableColumn<Process,Integer> BT;
    @FXML
    Button addButton;
    @FXML
    Button removeButton;
    @FXML
    Button nextButton;
    @FXML
    private Label AWT,ATAT,AWTval,ATATval;
    private ObservableList<Process> data =
        FXCollections.observableArrayList(
//            new Process("P1",0,10),
//            new Process("P2",2,8),
//            new Process("P3",1,4)
        );
    
    public void changeToSecondScreen(ActionEvent event) throws IOException, Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SecondView.fxml"));
        Parent wtRoot = (Parent) fxmlLoader.load();
        Scene wtScene = new Scene(wtRoot);
        wtScene.getStylesheets().add(getClass().getResource("secondview.css").toExternalForm());
        SecondViewController controller= fxmlLoader.getController();
        controller.setList(data);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(wtScene);
        window.show();
        
    }
    
    public void changeProcessNameCellEvent(CellEditEvent edittedCell){
        Process processSelected = table.getSelectionModel().getSelectedItem();
        processSelected.setProcessName(edittedCell.getNewValue().toString());
    }
 
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        pName.setCellValueFactory(new PropertyValueFactory<Process, String>("processName"));
        AT.setCellValueFactory(new PropertyValueFactory<Process, Integer>("arrivalTime"));
        BT.setCellValueFactory(new PropertyValueFactory<Process,Integer>("burstTime"));

        
        table.setItems(data);
        
        table.setEditable(true);
        
        pName.setCellFactory(TextFieldTableCell.forTableColumn());
        
    }
    
    @FXML
    private void onAddAction(ActionEvent event){
        
        Process process = new Process();
        process.setProcessName(nameInput.getText());
        process.setArrivalTime(Integer.parseInt(arrivalInput.getText()));
        process.setBurstTime(Integer.parseInt(burstInput.getText()));
        table.getItems().add(process);
        nameInput.clear();
        arrivalInput.clear();
        burstInput.clear();
       
        
    }
    
    @FXML
    private void onRemoveAction(ActionEvent event) {
        ObservableList<Process> processSelected,allProcess;
        allProcess = table.getItems();
        processSelected = table.getSelectionModel().getSelectedItems();
        processSelected.forEach(allProcess::remove);

    }
    
    
}
