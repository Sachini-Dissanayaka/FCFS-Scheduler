package cpuscheduler;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author PCnet Computers
 */
public class Data {
    
    private SimpleStringProperty processName,colour;
    private SimpleIntegerProperty arrivalTime;
    private SimpleIntegerProperty burstTime;
    private SimpleIntegerProperty waitingTime,xValue;
    private SimpleIntegerProperty turnaroundTime;
        

    private Data(SimpleStringProperty processName,SimpleIntegerProperty arrivalTime, SimpleIntegerProperty burstTime, SimpleIntegerProperty waitingTime, SimpleIntegerProperty turnaroundTime,SimpleStringProperty color,SimpleIntegerProperty xValue) {
        this.processName = processName;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.waitingTime = waitingTime;
        this.turnaroundTime = turnaroundTime; 
        this.xValue = xValue;
        this.colour = color;
    }
    
    public Data(){
        this.processName = new SimpleStringProperty("");
        this.arrivalTime = new SimpleIntegerProperty(0);
        this.burstTime =new SimpleIntegerProperty(0);
        this.waitingTime = new SimpleIntegerProperty(0);
        this.turnaroundTime =new SimpleIntegerProperty(0);
        this.colour = new SimpleStringProperty("");
        this.xValue = new SimpleIntegerProperty(0);
    }
        
    public Data(String pName,int aTime,int bTime,int wtTime,int tatTime,String colour){
        this.processName = new SimpleStringProperty(pName);
        this.arrivalTime = new SimpleIntegerProperty(aTime);
        this.burstTime = new SimpleIntegerProperty(bTime);
        this.waitingTime = new SimpleIntegerProperty(wtTime);
        this.turnaroundTime = new SimpleIntegerProperty(tatTime);
        this.colour = new SimpleStringProperty(colour);
    }
 
        public String getProcessName() {
            return processName.get();
        }
 
        public void setProcessName(String fName) {
//            processName.set(fName);
            this.processName = new SimpleStringProperty(fName);
        }
        public int getArrivalTime() {
        return arrivalTime.get();
    }

    public void setArrivalTime(int fName) {
        //arrivalTime.set(fName);
        this.arrivalTime = new SimpleIntegerProperty(fName);
    }

    public int getBurstTime() {
        return burstTime.get();
    }

    public void setBurstTime(int fName) {
        this.burstTime = new SimpleIntegerProperty(fName);
        //burstTime.set(fName);
    }
        
        public int getWaitingTime() {
            return waitingTime.get();
        }
 
        public void setWaitingTime(int fName) {
            this.waitingTime = new SimpleIntegerProperty(fName);
            
        }
        
        public int getTurnaroundTime() {
            return turnaroundTime.get();
        }
 
        public void setTurnaroundTime(int fName) {
            this.turnaroundTime = new SimpleIntegerProperty(fName);
            
        }
        public String getColour() {
            return colour.get();
        }

        public void setColour(String colour) {
            this.colour = new SimpleStringProperty(colour);
        }

        public int getxValue() {
            return xValue.get();
        }

        public void setxValue(int xValue) {
            this.xValue = new SimpleIntegerProperty(xValue);
        }
    
}
