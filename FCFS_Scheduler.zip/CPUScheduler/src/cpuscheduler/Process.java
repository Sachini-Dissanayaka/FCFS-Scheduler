/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpuscheduler;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author PCnet Computers
 */
public class Process {
 
        private SimpleStringProperty processName;
        private SimpleIntegerProperty arrivalTime;
        private SimpleIntegerProperty burstTime;
        

    private Process(SimpleStringProperty processName, SimpleIntegerProperty arrivalTime, SimpleIntegerProperty burstTime) {
        this.processName = processName;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        
    }
        
    public Process(){
        this.processName = new SimpleStringProperty("");
        this.arrivalTime = new SimpleIntegerProperty(0);
        this.burstTime =new SimpleIntegerProperty(0);

    }
       
    public Process(String pName, int aTime, int bTime) {
        this.processName = new SimpleStringProperty(pName);
        this.arrivalTime = new SimpleIntegerProperty(aTime);
        this.burstTime = new SimpleIntegerProperty(bTime);       
    }

    public String getProcessName() {
        return processName.get();
    }

    public void setProcessName(String fName) {
//            processName.set(fName);
        this.processName = new SimpleStringProperty(fName);
    }

    public int getArrivalTime() {
        return arrivalTime.get();
    }

    public void setArrivalTime(int fName) {
        //arrivalTime.set(fName);
        this.arrivalTime = new SimpleIntegerProperty(fName);
    }

    public int getBurstTime() {
        return burstTime.get();
    }

    public void setBurstTime(int fName) {
        this.burstTime = new SimpleIntegerProperty(fName);
        
    }

    


        
}